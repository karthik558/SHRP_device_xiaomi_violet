#!/sbin/sh
fstab="/vendor/etc/fstab.qcom"

if [ -f $fstab ];
then
	if grep -q inlinecrypt $fstab
	then
		sed -i 's/,inlinecrypt//' $fstab
	fi
	if grep -q fileencryption $fstab
	then
		sed -i 's|fileencryption=ice|encryptable=ice|' $fstab
	fi
fi
